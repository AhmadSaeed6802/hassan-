CREATE DATABASE BlogDB;
GO

USE BlogDB;
GO

CREATE TABLE Users (
    UserID int IDENTITY(1,1) NOT NULL,
    Username nvarchar(255) NOT NULL,
    Password nvarchar(255) NOT NULL,
    PRIMARY KEY (UserID)
);
GO

CREATE TABLE Categories (
    CategoryID int IDENTITY(1,1) NOT NULL,
    CategoryName nvarchar(255) NOT NULL,
    PRIMARY KEY (CategoryID)
);
GO

CREATE TABLE Posts (
    PostID int IDENTITY(1,1) NOT NULL,
    Title nvarchar(255) NOT NULL,
    Content nvarchar(MAX) NOT NULL,
    UserID int,
    CategoryID int,
    PublishDate datetime2 DEFAULT GETDATE(),
    PRIMARY KEY (PostID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);
GO

CREATE TABLE Comments (
    CommentID int IDENTITY(1,1) NOT NULL,
    UserID int,
    PostID int,
    Content nvarchar(MAX) NOT NULL,
    CommentDate datetime2 DEFAULT GETDATE(),
    PRIMARY KEY (CommentID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (PostID) REFERENCES Posts(PostID)
);
GO







-- CREATE User
CREATE PROCEDURE CreateUser
    @Username nvarchar(255),
    @Password nvarchar(255)
AS
INSERT INTO Users (Username, Password)
VALUES (@Username, @Password);
GO

-- READ User
CREATE PROCEDURE GetUser
    @UserID int
AS
SELECT * FROM Users
WHERE UserID = @UserID;
GO

-- UPDATE User
CREATE PROCEDURE UpdateUser
    @UserID int,
    @Username nvarchar(255),
    @Password nvarchar(255)
AS
UPDATE Users
SET Username = @Username, Password = @Password
WHERE UserID = @UserID;
GO

-- DELETE User
CREATE PROCEDURE DeleteUser
    @UserID int
AS
DELETE FROM Users
WHERE UserID = @UserID;
GO






-- CREATE Category
CREATE PROCEDURE CreateCategory
    @CategoryName nvarchar(255)
AS
INSERT INTO Categories (CategoryName)
VALUES (@CategoryName);
GO

-- READ Category
CREATE PROCEDURE GetCategory
    @CategoryID int
AS
SELECT * FROM Categories
WHERE CategoryID = @CategoryID;
GO

-- UPDATE Category
CREATE PROCEDURE UpdateCategory
    @CategoryID int,
    @CategoryName nvarchar(255)
AS
UPDATE Categories
SET CategoryName = @CategoryName
WHERE CategoryID = @CategoryID;
GO

-- DELETE Category
CREATE PROCEDURE DeleteCategory
    @CategoryID int
AS
DELETE FROM Categories
WHERE CategoryID = @CategoryID;
GO



-- CREATE Post
CREATE PROCEDURE CreatePost
    @Title nvarchar(255),
    @Content nvarchar(MAX),
    @UserID int,
    @CategoryID int
AS
INSERT INTO Posts (Title, Content, UserID, CategoryID)
VALUES (@Title, @Content, @UserID, @CategoryID);
GO

-- READ Post
CREATE PROCEDURE GetPost
    @PostID int
AS
SELECT * FROM Posts
WHERE PostID = @PostID;
GO

-- UPDATE Post
CREATE PROCEDURE UpdatePost
    @PostID int,
    @Title nvarchar(255),
    @Content nvarchar(MAX),
    @UserID int,
    @CategoryID int
AS
UPDATE Posts
SET Title = @Title, Content = @Content, UserID = @UserID, CategoryID = @CategoryID
WHERE PostID = @PostID;
GO

-- DELETE Post
CREATE PROCEDURE DeletePost
    @PostID int
AS
DELETE FROM Posts
WHERE PostID = @PostID;
GO


-- CREATE Comment
CREATE PROCEDURE CreateComment
    @UserID int,
    @PostID int,
    @Content nvarchar(MAX)
AS
INSERT INTO Comments (UserID, PostID, Content)
VALUES (@UserID, @PostID, @Content);
GO

-- READ Comment
CREATE PROCEDURE GetComment
    @CommentID int
AS
SELECT * FROM Comments
WHERE CommentID = @CommentID;
GO

-- UPDATE Comment
CREATE PROCEDURE UpdateComment
    @CommentID int,
    @UserID int,
    @PostID int,
    @Content nvarchar(MAX)
AS
UPDATE Comments
SET UserID = @UserID, PostID = @PostID, Content = @Content
WHERE CommentID = @CommentID;
GO

-- DELETE Comment
CREATE PROCEDURE DeleteComment
    @CommentID int
AS
DELETE FROM Comments
WHERE CommentID = @CommentID;
GO





-- Fetch posts with their corresponding comments
CREATE PROCEDURE GetPostsWithComments
AS
SELECT P.PostID, P.Title, C.CommentID, C.Content
FROM Posts P
LEFT JOIN Comments C ON P.PostID = C.PostID
ORDER BY P.PostID;
GO

-- Fetch posts by category
CREATE PROCEDURE GetPostsByCategory
    @CategoryID int
AS
SELECT * FROM Posts
WHERE CategoryID = @CategoryID;
GO

-- Fetch posts by user
CREATE PROCEDURE GetPostsByUser
    @UserID int
AS
SELECT * FROM Posts
WHERE UserID = @UserID;
GO
