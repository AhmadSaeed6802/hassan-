﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Web_API.Models
{
    public class Posts
    {
        public int PostId { get; set; }

        [Required(ErrorMessage = "Title is required.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Content is required.")]
        public string Content { get; set; }

        public DateTime CreatedAt { get; set; }

        [Required(ErrorMessage = "CategoryId is required.")]
        public int CategoryId { get; set; }
    }
}
