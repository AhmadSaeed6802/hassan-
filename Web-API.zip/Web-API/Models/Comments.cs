﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Web_API.Models
{
    public class Comments
    {
        public int CommentId { get; set; }

        [Required(ErrorMessage = "Content is required.")]
        public string Content { get; set; }

        public DateTime CreatedAt { get; set; }

        [Required(ErrorMessage = "PostId is required.")]
        public int PostId { get; set; }
    }
}
