﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{
    public class CommentsController : ApiController
    {
        private CommentBL _commentBL;

        public CommentsController(CommentBL commentBL)
        {
            _commentBL = commentBL;
        }

       
        [HttpGet]
        [Route("api/Comments")]
        public IHttpActionResult GetAllComments()
        {
            var comments = _commentBL.GetAllComments();
            if (comments == null || comments.Count == 0)
            {
                return NotFound();
            }

            return Ok(comments);
        }

        
        [HttpGet]
        [Route("api/Comments/{id}")]
        public IHttpActionResult GetComment(int id)
        {
            var comment = _commentBL.GetComment(id);
            if (comment == null)
            {
                return NotFound();
            }

            return Ok(comment);
        }

        
        [HttpPost]
        [Route("api/Comments")]
        public IHttpActionResult AddComment([FromBody] Comments comment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var createdComment = _commentBL.AddComment(comment);

            if (createdComment == null)
            {
                return BadRequest("Error adding comment.");
            }

            return Created("", createdComment);  
        }

       
        [HttpPut]
        [Route("api/Comments/{id}")]
        public IHttpActionResult UpdateComment(int id, [FromBody] Comments comment)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var updated = _commentBL.UpdateComment(id, comment);

            if (!updated)
            {
                return BadRequest("Error updating comment.");
            }

            return Ok();
        }

        
        [HttpDelete]
        [Route("api/Comments/{id}")]
        public IHttpActionResult DeleteComment(int id)
        {
            var deleted = _commentBL.DeleteComment(id);

            if (!deleted)
            {
                return BadRequest("Error deleting comment.");
            }

            return Ok();
        }
    }
}
