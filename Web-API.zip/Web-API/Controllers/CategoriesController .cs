﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{
    public class CategoriesController : ApiController
    {
        private CategoryBL _categoryBL;

        public CategoriesController(CategoryBL categoryBL)
        {
            _categoryBL = categoryBL;
        }

       
        [HttpGet]
        [Route("api/Categories")]
        public IHttpActionResult GetAllCategories()
        {
            var categories = _categoryBL.GetAllCategories();
            if (categories == null || categories.Count == 0)
            {
                return NotFound();
            }

            return Ok(categories);
        }

        
        [HttpGet]
        [Route("api/Categories/{id}")]
        public IHttpActionResult GetCategory(int id)
        {
            var category = _categoryBL.GetCategory(id);
            if (category == null)
            {
                return NotFound();
            }

            return Ok(category);
        }

        
        [HttpPost]
        [Route("api/Categories")]
        public IHttpActionResult AddCategory([FromBody] Categories category)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var createdCategory = _categoryBL.AddCategory(category);

            if (createdCategory == null)
            {
                return BadRequest("Error adding category.");
            }

            return Created("", createdCategory);  
        }

       
        [HttpPut]
        [Route("api/Categories/{id}")]
        public IHttpActionResult UpdateCategory(int id, [FromBody] Categories category)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var updated = _categoryBL.UpdateCategory(id, category);

            if (!updated)
            {
                return BadRequest("Error updating category.");
            }

            return Ok();
        }

       
        [HttpDelete]
        [Route("api/Categories/{id}")]
        public IHttpActionResult DeleteCategory(int id)
        {
            var deleted = _categoryBL.DeleteCategory(id);

            if (!deleted)
            {
                return BadRequest("Error deleting category.");
            }

            return Ok();
        }
    }
}
