﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{
    public class UsersController : ApiController
    {
        private UserBL _userBL;

        public UsersController(UserBL userBL)
        {
            _userBL = userBL;
        }

        
        [HttpGet]
        [Route("GetAllUsers")]
        public IHttpActionResult GetAllUsers()
        {
            var users = _userBL.GetAllUsers();
            if (users == null)
            {
                return NotFound();
            }

            return Ok(users);
        }

        
        [HttpGet]
        [Route("GetUser/{id}")]
        public IHttpActionResult GetUser(int id)
        {
            var user = _userBL.GetUser(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        
        [HttpPost]
        [Route("InsertUser")]
        public IHttpActionResult InsertUser([FromBody] Users user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var createdUser = _userBL.AddUser(user);

            if (createdUser == null)
            {
                return BadRequest("Error creating user.");
            }

            return Created("", createdUser);  
        }

       
        [HttpPut]
        [Route("UpdateUser/{id}")]
        public IHttpActionResult UpdateUser(int id, [FromBody] Users user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var updatedUser = _userBL.UpdateUser(id, user);

            if (updatedUser == null)
            {
                return BadRequest("Error updating user.");
            }

            return Ok(updatedUser);
        }

        
        [HttpDelete]
        [Route("DeleteUser/{id}")]
        public IHttpActionResult DeleteUser(int id)
        {
            var deleted = _userBL.DeleteUser(id);

            if (!deleted)
            {
                return BadRequest("Error deleting user.");
            }

            return Ok();
        }

        
        [HttpPost]
        [Route("RegisterUser")]
        public IHttpActionResult RegisterUser([FromBody] RegisterModel registrationData)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var createdUser = _userBL.RegisterUser(registrationData);

            if (createdUser == null)
            {
                return BadRequest("Error registering user.");
            }

            return Created("", createdUser);  
        }

        
        [HttpPost]
        [Route("Login")]
        public IHttpActionResult LoginUser([FromBody] LoginModel loginData)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var loggedInUser = _userBL.LoginUser(loginData);

            if (loggedInUser == null)
            {
                return BadRequest("Invalid username or password.");
            }

            return Ok(loggedInUser);
        }
    }
}
