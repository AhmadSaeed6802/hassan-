﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{
    public class PostsController : ApiController
    {
        private PostBL _postBL;

        public PostsController(PostBL postBL)
        {
            _postBL = postBL;
        }

        // GET: api/Posts
        [HttpGet]
        [Route("api/Posts")]
        public IHttpActionResult GetAllPosts()
        {
            List<Posts> posts = _postBL.GetAllPosts();
            return Ok(posts);
        }

        
        [HttpGet]
        [Route("api/Posts/{id}")]
        public IHttpActionResult GetPost(int id)
        {
            Posts post = _postBL.GetPost(id);
            if (post == null)
            {
                return NotFound();
            }
            return Ok(post);
        }

        
        [HttpPost]
        [Route("api/Posts")]
        public IHttpActionResult InsertPost([FromBody] Posts post)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            Posts newPost = _postBL.AddPost(post);
            return Created("", newPost);
        }

        
        [HttpPut]
        [Route("api/Posts/{id}")]
        public IHttpActionResult UpdatePost(int id, [FromBody] Posts post)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            if (id != post.PostId)
            {
                return BadRequest("Invalid PostId in the request body.");
            }

            bool updated = _postBL.UpdatePost(post);
            if (updated)
            {
                return Ok(post);
            }
            return BadRequest("Error updating post.");
        }

       
        [HttpDelete]
        [Route("api/Posts/{id}")]
        public IHttpActionResult DeletePost(int id)
        {
            bool deleted = _postBL.DeletePost(id);
            if (deleted)
            {
                return Ok();
            }
            return BadRequest("Error deleting post.");
        }
    }
}
