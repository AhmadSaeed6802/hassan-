// login.js
$(document).ready(function() {
    $('#loginForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        
        $.ajax({
            type: 'POST',
            url: 'api/LoginUser', // Replace with your actual API endpoint for user login
            data: formData,
            success: function(response) {
                // Handle successful login (e.g., store authentication token, redirect to home page)
                console.log('User logged in successfully:', response);
            },
            error: function(xhr, status, error) {
                // Handle login error (e.g., show error message)
                console.error('Login error:', error);
            }
        });
    });
});
