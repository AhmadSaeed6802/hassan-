// view_posts.js
$(document).ready(function() {
    // Function to fetch and display all posts
    function getAllPosts() {
        $.ajax({
            type: 'GET',
            url: 'api/GetAllPosts', // Replace with your actual API endpoint to fetch all posts
            success: function(posts) {
                // Iterate through posts and display them in the DOM
                var $postsList = $('#postsList');
                $postsList.empty();

                $.each(posts, function(index, post) {
                    var postHTML = '<div class="post">' +
                                    '<h2>' + post.title + '</h2>' +
                                    '<p>' + post.content + '</p>' +
                                    '</div>';
                    $postsList.append(postHTML);
                });
            },
            error: function(xhr, status, error) {
                console.error('Error fetching posts:', error);
            }
        });
    }

    // Call the function to get all posts on page load
    getAllPosts();
});
