// register.js
$(document).ready(function() {
    $('#registrationForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        
        $.ajax({
            type: 'POST',
            url: 'api/RegisterUser', // Replace with your actual API endpoint for user registration
            data: formData,
            success: function(response) {
                // Handle successful registration (e.g., show success message, redirect to login page)
                console.log('User registered successfully:', response);
            },
            error: function(xhr, status, error) {
                // Handle error (e.g., show error message)
                console.error('Registration error:', error);
            }
        });
    });
});
