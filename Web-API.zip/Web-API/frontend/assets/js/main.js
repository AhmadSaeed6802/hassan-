// main.js

$(document).ready(function() {
    // Function for user registration
    function registerUser() {
      var username = $("#username").val();
      var password = $("#password").val();
  
      // Make a POST request to the user registration API
      $.ajax({
        url: "/api/RegisterUser",
        type: "POST",
        data: JSON.stringify({ Username: username, Password: password }),
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("User registered successfully!");
          // Redirect to login page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for user login
    function loginUser() {
      var username = $("#username").val();
      var password = $("#password").val();
  
      // Make a POST request to the user login API
      $.ajax({
        url: "/api/Login",
        type: "POST",
        data: JSON.stringify({ Username: username, Password: password }),
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("User logged in successfully!");
          // Redirect to the dashboard page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for viewing all posts
    function viewAllPosts() {
      // Make a GET request to the API for fetching all posts
      $.ajax({
        url: "/api/GetAllPosts",
        type: "GET",
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          // Display the fetched posts on the page
          // You can dynamically generate HTML elements to display the posts and their details
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for viewing a single post with comments
    function viewSinglePostWithComments(postId) {
      // Make a GET request to the API for fetching a specific post and its comments
      $.ajax({
        url: "/api/GetPostWithComments/" + postId,
        type: "GET",
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          // Display the fetched post and its comments on the page
          // You can dynamically generate HTML elements to display the post and its comments
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for creating a new post
    function createPost() {
      var title = $("#title").val();
      var content = $("#content").val();
  
      // Make a POST request to the API for creating a new post
      $.ajax({
        url: "/api/CreatePost",
        type: "POST",
        data: JSON.stringify({ Title: title, Content: content }),
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("Post created successfully!");
          // Redirect to the dashboard or view post page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for updating a post
    function updatePost(postId) {
      var title = $("#title").val();
      var content = $("#content").val();
  
      // Make a PUT request to the API for updating a specific post
      $.ajax({
        url: "/api/UpdatePost/" + postId,
        type: "PUT",
        data: JSON.stringify({ Title: title, Content: content }),
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("Post updated successfully!");
          // Redirect to the dashboard or view post page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for deleting a post
    function deletePost(postId) {
      // Make a DELETE request to the API for deleting a specific post
      $.ajax({
        url: "/api/DeletePost/" + postId,
        type: "DELETE",
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("Post deleted successfully!");
          // Refresh the page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for creating a comment
    function createComment(postId) {
      var content = $("#commentContent").val();
  
      // Make a POST request to the API for creating a new comment for a specific post
      $.ajax({
        url: "/api/CreateComment",
        type: "POST",
        data: JSON.stringify({ PostId: postId, Content: content }),
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("Comment created successfully!");
          // Refresh the page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Function for deleting a comment
    function deleteComment(commentId) {
      // Make a DELETE request to the API for deleting a specific comment
      $.ajax({
        url: "/api/DeleteComment/" + commentId,
        type: "DELETE",
        contentType: "application/json; charset=utf-8",
        success: function(data) {
          alert("Comment deleted successfully!");
          // Refresh the page or do other actions as needed
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("Error: " + xhr.responseText);
        }
      });
    }
  
    // Call the relevant functions based on the page or user actions
    // For example, on the view post page, call viewSinglePostWithComments(postId)
    // when the user wants to view a specific post with comments.
  });
  