// view_post.js
$(document).ready(function() {
    // Function to fetch and display a single post with its comments
    function getPostWithComments(postId) {
        $.ajax({
            type: 'GET',
            url: 'api/GetPostWithComments/' + postId, // Replace with your actual API endpoint to fetch a single post with comments
            success: function(post) {
                // Display the post details
                var $postDetails = $('#postDetails');
                $postDetails.html('<h2>' + post.title + '</h2><p>' + post.content + '</p>');

                // Display comments
                var $commentsList = $('#commentsList');
                $commentsList.empty();

                $.each(post.comments, function(index, comment) {
                    var commentHTML = '<div class="comment">' +
                                      '<p>' + comment.text + '</p>' +
                                      '</div>';
                    $commentsList.append(commentHTML);
                });
            },
            error: function(xhr, status, error) {
                console.error('Error fetching post:', error);
            }
        });
    }

    // Get the postId from the URL (e.g., /view_post.html?id=1)
    var postId = window.location.search.split('=')[1];
    if (postId) {
        // Call the function to get the post details on page load
        getPostWithComments(postId);
    }
});
