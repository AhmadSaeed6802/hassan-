// edit_post.js
$(document).ready(function() {
    // Get the postId from the URL (e.g., /edit_post.html?id=1)
    var postId = window.location.search.split('=')[1];

    if (postId) {
        // Function to fetch and display post details for editing
        function getPostDetails(postId) {
            $.ajax({
                type: 'GET',
                url: 'api/GetPost/' + postId, // Replace with your actual API endpoint to fetch post details for editing
                success: function(post) {
                    // Display post details in the form for editing
                    $('#title').val(post.title);
                    $('#content').val(post.content);
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching post details:', error);
                }
            });
        }

        // Call the function to get post details for editing on page load
        getPostDetails(postId);

        $('#editPostForm').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
                type: 'PUT',
                url: 'api/UpdatePost/' + postId, // Replace with your actual API endpoint to update the post
                data: formData,
                success: function(response) {
                    // Handle successful post update (e.g., show success message, redirect to view post page)
                    console.log('Post updated successfully:', response);
                },
                error: function(xhr, status, error) {
                    // Handle error (e.g., show error message)
                    console.error('Post update error:', error);
                }
            });
        });
    }
});
