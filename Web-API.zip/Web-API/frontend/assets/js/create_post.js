// create_post.js
$(document).ready(function() {
    $('#createPostForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        
        $.ajax({
            type: 'POST',
            url: 'api/CreatePost', // Replace with your actual API endpoint to create a new post
            data: formData,
            success: function(response) {
                // Handle successful post creation (e.g., show success message, redirect to view post page)
                console.log('Post created successfully:', response);
            },
            error: function(xhr, status, error) {
                // Handle error (e.g., show error message)
                console.error('Post creation error:', error);
            }
        });
    });
});
