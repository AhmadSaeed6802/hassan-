﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using Web_API.Models;

namespace Web_API.Data_Layer
{
    public class CategoryDataLayer
    {
        string _connectionString = "";

        public CategoryDataLayer()
        {
            _connectionString = WebConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        }

        public List<Categories> GetAllCategories()
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetAllCategories", con);
                command.CommandType = CommandType.StoredProcedure;

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                con.Close();
            }

            List<Categories> categoriesList = new List<Categories>();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                Categories category = new Categories
                {
                    CategoryId = Convert.ToInt32(dataRow["CategoryId"]),
                    CategoryName = dataRow["CategoryName"].ToString()
                };

                categoriesList.Add(category);
            }

            return categoriesList;
        }

        public Categories GetCategory(int id)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetCategory", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CategoryID", id);

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                con.Close();
            }

            if (dataTable.Rows.Count > 0)
            {
                DataRow dataRow = dataTable.Rows[0];
                Categories category = new Categories
                {
                    CategoryId = Convert.ToInt32(dataRow["CategoryId"]),
                    CategoryName = dataRow["CategoryName"].ToString()
                };

                return category;
            }

            return null;
        }

        public int InsertCategory(Categories category)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("InsertCategory", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CategoryName", category.CategoryName);

                SqlParameter param = new SqlParameter("@CategoryId", SqlDbType.Int);
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                con.Open();
                command.ExecuteNonQuery();
                con.Close();

                int categoryId = Convert.ToInt32(command.Parameters["@CategoryId"].Value);
                return categoryId;
            }
        }

        public bool UpdateCategory(int id, Categories category)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("UpdateCategory", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CategoryID", id);
                command.Parameters.AddWithValue("@CategoryName", category.CategoryName);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                con.Close();

                return rowsAffected > 0;
            }
        }

        public bool DeleteCategory(int id)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("DeleteCategory", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CategoryID", id);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                con.Close();

                return rowsAffected > 0;
            }
        }
    }
}
