﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using Web_API.Models;

namespace Web_API.Data_Layer
{
    public class UserDataLayer
    {
        string _connectionString = "";

        public UserDataLayer()
        {
            _connectionString = WebConfigurationManager.ConnectionStrings["BlogDB"].ConnectionString;
        }

        public DataTable GetAllUsers()
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetAllUsers", con);
                command.CommandType = CommandType.StoredProcedure;

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
            }
            return dataTable;
        }

        public DataTable GetUser(int id)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetUser", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserID", id);

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
            }
            return dataTable;
        }

        public int InsertUser(Users user)
        {
            int userId = 0;
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("InsertUser", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", user.UserName);
                command.Parameters.AddWithValue("@Password", user.UserPassword);

                command.Parameters.Add("@UserID", SqlDbType.Int, 32);
                command.Parameters["@UserID"].Direction = ParameterDirection.Output;

                con.Open();
                command.ExecuteNonQuery();

                userId = Convert.ToInt32(command.Parameters["@UserID"].Value);
            }
            return userId;
        }

        public bool UpdateUser(int id, Users user)
        {
            bool isUpdated = false;
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("UpdateUser", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserID", id);
                command.Parameters.AddWithValue("@Username", user.UserName);
                command.Parameters.AddWithValue("@Password", user.UserPassword);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                isUpdated = rowsAffected > 0;
            }
            return isUpdated;
        }

        public bool DeleteUser(int id)
        {
            bool isDeleted = false;
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("DeleteUser", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserID", id);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                isDeleted = rowsAffected > 0;
            }
            return isDeleted;
        }

        public Users GetUserByUsernameAndPassword(string username, string password)
        {
            Users user = null;
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetUserByUsernameAndPassword", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                con.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    user = new Users
                    {
                        UserId = Convert.ToInt32(reader["UserId"]),
                        UserName = reader["UserName"].ToString(),
                        UserPassword = reader["UserPassword"].ToString()
                    };
                }

                reader.Close();
            }
            return user;
        }
    }
}
