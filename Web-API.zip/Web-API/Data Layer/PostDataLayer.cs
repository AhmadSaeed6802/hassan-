﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using Web_API.Models;

namespace Web_API.Data_Layer
{
    public class PostDataLayer
    {
        private string _connectionString;

        public PostDataLayer()
        {
            _connectionString = WebConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        }

        public List<Posts> GetAllPosts()
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetAllPosts", con);
                command.CommandType = CommandType.StoredProcedure;

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                con.Close();
            }

            List<Posts> postsList = new List<Posts>();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                Posts post = new Posts
                {
                    PostId = Convert.ToInt32(dataRow["PostId"]),
                    Title = dataRow["Title"].ToString(),
                    Content = dataRow["Content"].ToString(),
                    CreatedAt = Convert.ToDateTime(dataRow["CreatedAt"]),
                    CategoryId = Convert.ToInt32(dataRow["CategoryId"])
                };
                postsList.Add(post);
            }

            return postsList;
        }

        public Posts GetPost(int postId)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetPost", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@PostId", postId);

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                con.Close();
            }

            if (dataTable.Rows.Count > 0)
            {
                DataRow dataRow = dataTable.Rows[0];
                Posts post = new Posts
                {
                    PostId = Convert.ToInt32(dataRow["PostId"]),
                    Title = dataRow["Title"].ToString(),
                    Content = dataRow["Content"].ToString(),
                    CreatedAt = Convert.ToDateTime(dataRow["CreatedAt"]),
                    CategoryId = Convert.ToInt32(dataRow["CategoryId"])
                };
                return post;
            }

            return null;
        }

        public int InsertPost(Posts post)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("InsertPost", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Title", post.Title);
                command.Parameters.AddWithValue("@Content", post.Content);
                command.Parameters.AddWithValue("@CreatedAt", post.CreatedAt);
                command.Parameters.AddWithValue("@CategoryId", post.CategoryId);

                con.Open();
                int postId = Convert.ToInt32(command.ExecuteScalar());
                con.Close();

                return postId;
            }
        }

        public bool UpdatePost(Posts post)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("UpdatePost", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@PostId", post.PostId);
                command.Parameters.AddWithValue("@Title", post.Title);
                command.Parameters.AddWithValue("@Content", post.Content);
                command.Parameters.AddWithValue("@CreatedAt", post.CreatedAt);
                command.Parameters.AddWithValue("@CategoryId", post.CategoryId);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                con.Close();

                return rowsAffected > 0;
            }
        }

        public bool DeletePost(int postId)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("DeletePost", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@PostId", postId);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                con.Close();

                return rowsAffected > 0;
            }
        }
    }
}
