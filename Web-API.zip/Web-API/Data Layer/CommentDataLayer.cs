﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using Web_API.Models;

namespace Web_API.Data_Layer
{
    public class CommentDataLayer
    {
        string _connectionString = "";

        public CommentDataLayer()
        {
            _connectionString = WebConfigurationManager.ConnectionStrings["DemoCN"].ConnectionString;
        }

        public List<Comments> GetAllComments()
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetAllComments", con);
                command.CommandType = CommandType.StoredProcedure;

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                con.Close();
            }

            List<Comments> commentsList = new List<Comments>();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                Comments comment = new Comments
                {
                    CommentId = Convert.ToInt32(dataRow["CommentId"]),
                    Content = dataRow["Content"].ToString(),
                    CreatedAt = Convert.ToDateTime(dataRow["CreatedAt"]),
                    PostId = Convert.ToInt32(dataRow["PostId"])
                };

                commentsList.Add(comment);
            }

            return commentsList;
        }

        public Comments GetComment(int id)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("GetComment", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CommentID", id);

                con.Open();

                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
                con.Close();
            }

            if (dataTable.Rows.Count > 0)
            {
                DataRow dataRow = dataTable.Rows[0];
                Comments comment = new Comments
                {
                    CommentId = Convert.ToInt32(dataRow["CommentId"]),
                    Content = dataRow["Content"].ToString(),
                    CreatedAt = Convert.ToDateTime(dataRow["CreatedAt"]),
                    PostId = Convert.ToInt32(dataRow["PostId"])
                };

                return comment;
            }

            return null;
        }

        public int InsertComment(Comments comment)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("InsertComment", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Content", comment.Content);
                command.Parameters.AddWithValue("@CreatedAt", comment.CreatedAt);
                command.Parameters.AddWithValue("@PostId", comment.PostId);

                SqlParameter param = new SqlParameter("@CommentId", SqlDbType.Int);
                param.Direction = ParameterDirection.Output;
                command.Parameters.Add(param);

                con.Open();
                command.ExecuteNonQuery();
                con.Close();

                int commentId = Convert.ToInt32(command.Parameters["@CommentId"].Value);
                return commentId;
            }
        }

        public bool UpdateComment(int id, Comments comment)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("UpdateComment", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CommentID", id);
                command.Parameters.AddWithValue("@Content", comment.Content);
                command.Parameters.AddWithValue("@CreatedAt", comment.CreatedAt);
                command.Parameters.AddWithValue("@PostId", comment.PostId);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                con.Close();

                return rowsAffected > 0;
            }
        }

        public bool DeleteComment(int id)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("DeleteComment", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@CommentID", id);

                con.Open();
                int rowsAffected = command.ExecuteNonQuery();
                con.Close();

                return rowsAffected > 0;
            }
        }
    }
}
