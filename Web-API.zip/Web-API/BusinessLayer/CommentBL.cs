﻿using System;
using System.Collections.Generic;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class CommentBL
    {
        private CommentDataLayer _commentDataLayer = new CommentDataLayer();

        public List<Comments> GetAllComments()
        {
            try
            {
                return _commentDataLayer.GetAllComments();
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetAllComments due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Comments GetComment(int id)
        {
            try
            {
                return _commentDataLayer.GetComment(id);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetComment due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Comments AddComment(Comments comment)
        {
            try
            {
                comment.CreatedAt = DateTime.Now;
                int commentId = _commentDataLayer.InsertComment(comment);
                comment.CommentId = commentId;
                return comment;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in AddComment due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public bool UpdateComment(int id, Comments comment)
        {
            try
            {
                return _commentDataLayer.UpdateComment(id, comment);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in UpdateComment due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public bool DeleteComment(int id)
        {
            try
            {
                return _commentDataLayer.DeleteComment(id);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in DeleteComment due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}
