﻿using System;
using System.Collections.Generic;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class CategoryBL
    {
        private CategoryDataLayer _categoryDataLayer = new CategoryDataLayer();

        public List<Categories> GetAllCategories()
        {
            try
            {
                return _categoryDataLayer.GetAllCategories();
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetAllCategories due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Categories GetCategory(int id)
        {
            try
            {
                return _categoryDataLayer.GetCategory(id);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetCategory due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Categories AddCategory(Categories category)
        {
            try
            {
                int categoryId = _categoryDataLayer.InsertCategory(category);
                category.CategoryId = categoryId;
                return category;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in AddCategory due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public bool UpdateCategory(int id, Categories category)
        {
            try
            {
                return _categoryDataLayer.UpdateCategory(id, category);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in UpdateCategory due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public bool DeleteCategory(int id)
        {
            try
            {
                return _categoryDataLayer.DeleteCategory(id);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in DeleteCategory due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}
