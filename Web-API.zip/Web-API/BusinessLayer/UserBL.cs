﻿using System;
using System.Collections.Generic;
using System.Data;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class UserBL
    {
        private UserDataLayer _userDataLayer = new UserDataLayer();

        public List<Users> GetAllUsers()
        {
            try
            {
                DataTable table = _userDataLayer.GetAllUsers();
                List<Users> listUsers = new List<Users>();

                if (table != null && table.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in table.Rows)
                    {
                        Users user = new Users();
                        user.UserId = Convert.ToInt32(dataRow["UserId"]);
                        user.UserName = dataRow["UserName"].ToString();
                        user.UserPassword = dataRow["UserPassword"].ToString();
                        listUsers.Add(user);
                    }
                }
                return listUsers;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetAllUsers due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Users GetUser(int id)
        {
            try
            {
                DataTable table = _userDataLayer.GetUser(id);
                if (table != null && table.Rows.Count > 0)
                {
                    DataRow dataRow = table.Rows[0];
                    Users user = new Users();
                    user.UserId = Convert.ToInt32(dataRow["UserId"]);
                    user.UserName = dataRow["UserName"].ToString();
                    user.UserPassword = dataRow["UserPassword"].ToString();
                    return user;
                }
                return null;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetUser due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Users AddUser(Users user)
        {
            try
            {
                int userId = _userDataLayer.InsertUser(user);
                if (userId > 0)
                {
                    user.UserId = userId;
                    return user;
                }
                return null;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in AddUser due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Users UpdateUser(int id, Users user)
        {
            try
            {
                bool isUpdated = _userDataLayer.UpdateUser(id, user);
                if (isUpdated)
                {
                    return user;
                }
                return null;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in UpdateUser due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public bool DeleteUser(int id)
        {
            try
            {
                return _userDataLayer.DeleteUser(id);
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in DeleteUser due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Users RegisterUser(RegisterModel registrationData)
        {
            try
            {

                Users newUser = new Users
                {
                    UserName = registrationData.Username,
                    UserPassword = registrationData.Password
                };

                int userId = _userDataLayer.InsertUser(newUser);
                if (userId > 0)
                {
                    newUser.UserId = userId;
                    return newUser;
                }
                return null;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in RegisterUser due to "
                   + exception.Message, exception.InnerException);
            }
        }

        public Users LoginUser(LoginModel loginData)
        {
            try
            {
                
                Users user = _userDataLayer.GetUserByUsernameAndPassword(loginData.Username, loginData.Password);
                return user;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in LoginUser due to "
                   + exception.Message, exception.InnerException);
            }
        }
    }
}
