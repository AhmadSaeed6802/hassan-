﻿using System;
using System.Collections.Generic;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class PostBL
    {
        private PostDataLayer _postDataLayer = new PostDataLayer();

        public List<Posts> GetAllPosts()
        {
            return _postDataLayer.GetAllPosts();
        }

        public Posts GetPost(int postId)
        {
            return _postDataLayer.GetPost(postId);
        }

        public Posts AddPost(Posts post)
        {
            int postId = _postDataLayer.InsertPost(post);
            post.PostId = postId;
            return post;
        }

        public bool UpdatePost(Posts post)
        {
            return _postDataLayer.UpdatePost(post);
        }

        public bool DeletePost(int postId)
        {
            return _postDataLayer.DeletePost(postId);
        }
    }
}
